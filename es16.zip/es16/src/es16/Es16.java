/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es16;

import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;


public class Es16 {

    private double latitude;
    private double longitude;
    private Date sunrise;
    private Date sunset;
    private String cityName;

    public Es16(double lat, double lon) throws IOException, ParseException {
        String apiKey = "b4c0400f82bda629aa58b82f591f4602";
        String url = "https://api.openweathermap.org/data/2.5/weather?lat=" + lat + "&lon=" + lon + "&appid=" + apiKey + "&units=metric";

        JsonReader reader = Json.createReader(new URL(url).openStream());
        JsonObject json = reader.readObject();
        reader.close();

        latitude = json.getJsonObject("coord").getJsonNumber("lat").doubleValue();
        longitude = json.getJsonObject("coord").getJsonNumber("lon").doubleValue();
        cityName = json.getJsonString("name").getString();

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

        sunrise = new Date(json.getJsonObject("sys").getJsonNumber("sunrise").longValue() * 1000);
        sunset = new Date(json.getJsonObject("sys").getJsonNumber("sunset").longValue() * 1000);
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public Date getSunrise() {
        return sunrise;
    }

    public Date getSunset() {
        return sunset;
    }
    
    public String getCityName() {
        return cityName;
    }

    public static void main(String[] args) throws IOException, ParseException {
        Es16 info = new Es16(41.8947, 12.4839); // coordinate di Roma

        System.out.println("Latitudine: " + info.getLatitude());
        System.out.println("Longitudine: " + info.getLongitude());
        System.out.println("Citta: " + info.getCityName());

        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss dd-MM-yyyy");
        System.out.println("Alba: " + dateFormat.format(info.getSunrise()));
        System.out.println("Tramonto: " + dateFormat.format(info.getSunset()));
    }

}

